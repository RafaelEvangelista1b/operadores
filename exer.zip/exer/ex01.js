let num = 10;
console.log(x);