// Serão exibidas as menssagens: Hello, Default Value, 42
// A menssagem World não será exibida pois a uma aspas antes da menssagem World.
console.log(0 || "Hello");
console.log("" && "World");
console.log(null ?? "Default Value");
console.log(undefined ?? 42);