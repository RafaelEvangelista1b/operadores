let resultado = 10 + 5 * 2 > 20 && !false;
console.log(resultado);

// O resultado exibido será falso, pois na expressão há um sinal de maior comparando os valores.
// Ao colocar o sinal >= o resultado exibido será true.