console.log("5" - 2);
// O valor exibido será 3, pois será feita a operação de subtração
console.log("5" + 2);
// O valor exibido será 52, pois o sinal de + junta a string com o valor fora das aspas
console.log(true + 1);
// O valor exibido será 2, pois a uma operação de soma com o número 1 mais a sintaxe true e no código binário a menssagem true vale 1 
console.log(false + 10);
// O valor exibido será 10, pois a uma operação de subtrção com o número 10 menos a sintaxe false e no código binário a menssagem false vale 0 