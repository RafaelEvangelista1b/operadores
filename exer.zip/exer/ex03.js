let num = -15;
console.log(-(num))