count = 5;
console.log(++count);
console.log(--count)