let p = true;
let q = false;
console.log(p && q);
console.log(p || q);
console.log(!p);
console.log(!q);
