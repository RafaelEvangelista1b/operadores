x = 10 
console.log(x += 5);
console.log(x -= 3);
console.log(x *= 2);
console.log(x /= 4);
console.log(x %= 3);


