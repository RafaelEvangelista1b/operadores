let a = 20;
let b = 5;
console.log('Soma = ' + (a + b));
console.log('Subtração = ' + (a - b));
console.log('Multiplicação = ' + (a * b));
console.log('Divisão = ' + (a / b));
console.log('Resto = ' + (a % b));


